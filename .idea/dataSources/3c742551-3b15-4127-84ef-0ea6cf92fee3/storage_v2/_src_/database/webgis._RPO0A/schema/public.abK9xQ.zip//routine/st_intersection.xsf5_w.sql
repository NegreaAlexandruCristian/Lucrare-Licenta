create function st_intersection(rast1 raster, rast2 raster, returnband text DEFAULT 'BOTH'::text, nodataval double precision[] DEFAULT NULL::double precision[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT st_intersection($1, 1, $2, 1, $3, $4)
$$;

alter function st_intersection(raster, raster, text, double precision[]) owner to postgres;

