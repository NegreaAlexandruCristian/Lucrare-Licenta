create function st_within(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) $3 AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN public._st_within(public.st_convexhull($1), public.st_convexhull($3)) ELSE public._st_contains($3, $4, $1, $2) END
$$;

comment on function st_within(raster, integer, raster, integer) is 'args: rastA, nbandA, rastB, nbandB - Return true if no points of raster rastA lie in the exterior of raster rastB and at least one point of the interior of rastA lies in the interior of rastB.';

alter function st_within(raster, integer, raster, integer) owner to postgres;

