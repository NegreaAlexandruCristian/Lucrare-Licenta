create function st_disjoint(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT CASE WHEN $2 IS NULL OR $4 IS NULL THEN public.ST_Disjoint(public.ST_ConvexHull($1), public.ST_ConvexHull($3)) ELSE NOT public._ST_intersects($1, $2, $3, $4) END
$$;

comment on function st_disjoint(raster, integer, raster, integer) is 'args: rastA, nbandA, rastB, nbandB - Return true if raster rastA does not spatially intersect rastB.';

alter function st_disjoint(raster, integer, raster, integer) owner to postgres;

