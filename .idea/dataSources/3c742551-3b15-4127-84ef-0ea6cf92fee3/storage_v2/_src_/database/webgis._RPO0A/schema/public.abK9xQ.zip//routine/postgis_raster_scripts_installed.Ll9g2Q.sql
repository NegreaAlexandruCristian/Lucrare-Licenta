create function postgis_raster_scripts_installed() returns text
    immutable
    parallel safe
    language sql
as
$$
SELECT trim('3.0.2'::text || $rev$ 3.0.2 $rev$) AS version
$$;

alter function postgis_raster_scripts_installed() owner to postgres;

